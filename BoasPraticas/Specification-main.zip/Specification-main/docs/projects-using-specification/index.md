---
layout: default
title: Projects Using Specification
nav_order: 7
has_children: true
---

# Projects using Ardalis.Specification

## Contents (to do)

- [eShopOnWeb Reference App](https://github.com/dotnet-architecture/eShopOnWeb)
- [Pluralsight DDD Fundamentals Course sample](https://github.com/ardalis/pluralsight-ddd-fundamentals)
- [CleanArchitecture Solution Template](https://github.com/ardalis/CleanArchitecture)
- [fullstackhero Web API Boilerplate](https://github.com/fullstackhero/dotnet-webapi-boilerplate)
- (add your own project here via [pull request](https://github.com/ardalis/Specification/pulls))
