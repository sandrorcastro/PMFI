---
layout: default
title: PostProcessingAction
nav_order: 9
has_children: false
parent: Base Features
grand_parent: Features
---

# PostProcessingAction

See [this issue for details](https://github.com/ardalis/Specification/pull/56).

## Example

TODO
