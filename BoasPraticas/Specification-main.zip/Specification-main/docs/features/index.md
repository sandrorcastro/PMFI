---
layout: default
title: Features
nav_order: 4
has_children: true
---

# Ardalis.Specification Features

Detailed review of supported features.
