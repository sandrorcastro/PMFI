---
layout: default
title: Base Features
nav_order: 1
has_children: true
parent: Features
---

# Base Features

The features described in the docs below all work as they do in Linq. For explanations beyond those provided below, you may find the Methods section of the [Linq docs](https://docs.microsoft.com/en-us/dotnet/api/system.linq.enumerable?view=net-5.0) helpful.
