---
layout: default
title: Videos
parent: Related Resources
nav_order: 2
---

# Specification Videos

Below are some videos related to this project.

- 5 March 2021: [What's new in v5 of Ardalis.Specification](https://www.youtube.com/watch?v=gT72mWdD4Qo&ab_channel=Ardalis)
- 6 November 2020: [Overiew - Working with Ardalis.Specification](https://www.youtube.com/watch?v=BgWWbBUWyig&t=1545s&ab_channel=Ardalis)
- [Additional streams and videos](https://www.youtube.com/c/Ardalis/search?query=specification)
