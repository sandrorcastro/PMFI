---
layout: default
title: Articles
parent: Related Resources
nav_order: 3
---

# Specification Articles

Below are some articles related to this project and/or the specification design pattern.

- [Specification Pattern](https://deviq.com/design-patterns/specification-pattern)
- [Martin Fowler PDF](https://www.martinfowler.com/apsupp/spec.pdf)
