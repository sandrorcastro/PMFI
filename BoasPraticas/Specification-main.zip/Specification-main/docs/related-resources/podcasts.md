---
layout: default
title: Podcasts
parent: Related Resources
nav_order: 4
---

# Specification Podcasts

Below are some podcast episodes related to this project and/or the specification design pattern.

- [Layering Patterns on Repositories](https://www.weeklydevtips.com/episodes/026)
