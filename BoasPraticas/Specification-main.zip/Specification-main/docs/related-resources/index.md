---
layout: default
title: Related Resources
nav_order: 6
has_children: true
---

# Related Resources

Additional resources to learn more about the Specification pattern and related topics like Repository and Domain-Driven Design.
