﻿namespace Ardalis.Sample.Domain;

public interface IAggregateRoot
{
}
