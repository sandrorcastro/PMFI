﻿namespace Ardalis.Specification;

public enum IncludeTypeEnum
{
    Include = 1,
    ThenInclude = 2
}
