﻿global using Ardalis.Specification.UnitTests.Fixture.Entities;
global using Ardalis.Specification.UnitTests.Fixture.Specs;
global using FluentAssertions;
global using System.Linq;
global using Xunit;
