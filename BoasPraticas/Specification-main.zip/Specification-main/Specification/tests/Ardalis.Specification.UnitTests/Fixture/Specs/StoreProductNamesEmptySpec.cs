﻿namespace Ardalis.Specification.UnitTests.Fixture.Specs;

public class StoreProductNamesEmptySpec : Specification<Store, string?>
{
    public StoreProductNamesEmptySpec()
    {

    }
}
