﻿namespace Ardalis.Specification.UnitTests.Fixture.Specs;

public class StoreNamesEmptySpec : Specification<Store, string>
{
    public StoreNamesEmptySpec()
    {

    }
}
