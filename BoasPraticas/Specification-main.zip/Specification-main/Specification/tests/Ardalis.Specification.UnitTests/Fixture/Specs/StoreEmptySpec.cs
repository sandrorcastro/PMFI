﻿namespace Ardalis.Specification.UnitTests.Fixture.Specs;

public class StoreEmptySpec : Specification<Store>
{
    public StoreEmptySpec()
    {

    }
}
