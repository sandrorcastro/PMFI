﻿namespace Microsoft.eShopWeb.PublicApi;

/// <summary>
/// Base class used by API requests
/// </summary>
public abstract class BaseRequest : BaseMessage
{
}
