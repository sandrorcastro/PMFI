﻿namespace Clean.Architecture.Web.Endpoints.ContributorEndpoints;

public record ContributorRecord(int Id, string Name);
