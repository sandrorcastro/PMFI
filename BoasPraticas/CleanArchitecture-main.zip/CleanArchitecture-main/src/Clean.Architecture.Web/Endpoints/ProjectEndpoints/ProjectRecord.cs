﻿namespace Clean.Architecture.Web.Endpoints.ProjectEndpoints;

public record ProjectRecord(int Id, string Name);
