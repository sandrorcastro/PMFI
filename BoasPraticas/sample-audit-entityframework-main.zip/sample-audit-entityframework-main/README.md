# sample-audit-entityframework

- .NET 7.0
- Swashbuckle Swagger
- Serilog

https://henriquemauri.net/trilha-de-auditoria-no-net-com-o-entity-framework-core/
